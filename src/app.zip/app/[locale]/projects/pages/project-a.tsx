export default function ProjectA() {
    return (
        <div>
            <h1>Project A</h1>
            <p>Detailed description of Project A.</p>
            <img src="/images/projects/project-a.jpg" alt="Project A" />
        </div>
    );
}
